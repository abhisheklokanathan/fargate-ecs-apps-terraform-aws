import boto3
import json
import zipfile
import io
import time

# Configuration
LAMBDA_FUNCTION_NAME = 'versionedUriRewriter-tf'
S3_BUCKET = 'aws-mypersonal-website-tf'
ROOT_JSON_KEY = 'root.json'

# Clients
s3 = boto3.client('s3')
lambda_client = boto3.client('lambda', region_name='us-east-1')

def lambda_handler(event=None, context=None):
    # Step 1: Read version from S3
    response = s3.get_object(Bucket=S3_BUCKET, Key=ROOT_JSON_KEY)
    root_json = json.loads(response['Body'].read())
    version = root_json.get('version')
    if not version:
        raise Exception("❌ Version not found in root.json")

    print(f"✅ Found version: {version}")

    # Step 2: Generate Lambda code
    edge_code = generate_lambda_code(version)
    zip_bytes = create_zip(edge_code)

    # Step 3: Update function code
    lambda_client.update_function_code(
        FunctionName=LAMBDA_FUNCTION_NAME,
        ZipFile=zip_bytes,
        Publish=False  # We’ll publish manually after the update
    )

    # Step 4: Wait briefly before publishing new version
    print("⏳ Waiting for update to finish before publishing new version...")
    time.sleep(10)  # Wait for 10 seconds (adjustable)

    # Step 5: Publish new version
    try:
        publish_resp = lambda_client.publish_version(FunctionName=LAMBDA_FUNCTION_NAME)
        new_version = publish_resp['Version']
        new_arn = publish_resp['FunctionArn']
        print(f"✅ Published Lambda version: {new_version}")
    except Exception as e:
        print(f"❌ Error publishing version: {str(e)}")

    return {
        'statusCode': 200,
        'body': json.dumps({'version': version, 'publishedVersion': new_version})
    }

def generate_lambda_code(version):
    return f"""
def lambda_handler(event, context):
    request = event['Records'][0]['cf']['request']
    uri = request['uri']
    version = "{version}"

    if uri == '/' or not uri.startswith('/' + version + '/'):
        if uri == '/':
            request['uri'] = '/' + version + '/index.html'
        else:
            request['uri'] = '/' + version + uri
    return request
"""

def create_zip(code_str):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as zipf:
        zipf.writestr('lambda_function.py', code_str)
    buffer.seek(0)
    return buffer.read()