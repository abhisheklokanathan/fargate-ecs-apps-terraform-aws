def lambda_handler(event, context):
    request = event['Records'][0]['cf']['request']
    uri = request['uri']
    version = "1.69.0"

    if uri == '/' or not uri.startswith('/' + version + '/'):
        if uri == '/':
            request['uri'] = '/' + version + '/index.html'
        else:
            request['uri'] = '/' + version + uri
    return request